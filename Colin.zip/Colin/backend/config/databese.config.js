module.exports = {
    URL: 'mongodb+srv://zky20020612:Kyxc2002@charlie.uo1ej1f.mongodb.net/?retryWrites=true&w=majority'
}